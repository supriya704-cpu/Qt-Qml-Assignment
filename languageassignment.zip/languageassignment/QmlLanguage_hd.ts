<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hi_IN" sourcelanguage="en_GB">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="59"/>
        <location filename="main.qml" line="60"/>
        <source>Hello World</source>
        <translation>नमस्ते दुनिया</translation>
    </message>
    <message>
        <location filename="main.qml" line="61"/>
        <source>The QTranslator class provides internationalizationsupport for text output.An object of this class contains a set of translations from a source language to a target language. QTranslator provides functions to look up translations in a translation file. Translation files are created using Qt Linguist.</source>
        <translation>क्यूट्रांसलेटर वर्ग अंतर्राष्ट्रीयकरण प्रदान करता है &quot;+
                              &quot;टेक्स्ट आउटपुट के लिए समर्थन। इस वर्ग के ऑब्जेक्ट में&quot; + शामिल हैं
                              &quot;स्रोत भाषा से लक्ष्य भाषा में अनुवाद का एक सेट।&quot; +
                              &quot;क्यूट्रांसलेटर एक अनुवाद फ़ाइल में अनुवाद देखने के लिए कार्य प्रदान करता है।&quot; +
                              &quot;Qt भाषाविद् का उपयोग करके अनुवाद फाइलें बनाई जाती हैं।</translation>
    </message>
</context>
</TS>
