<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="te_IN">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="59"/>
        <location filename="main.qml" line="60"/>
        <source>Hello World</source>
        <translation>హలో ప్రపంచం</translation>
    </message>
    <message>
        <location filename="main.qml" line="61"/>
        <source>The QTranslator class provides internationalizationsupport for text output.An object of this class contains a set of translations from a source language to a target language. QTranslator provides functions to look up translations in a translation file. Translation files are created using Qt Linguist.</source>
        <translation>QTranslator తరగతి టెక్స్ట్ అవుట్‌పుట్ కోసం అంతర్జాతీయీకరణ మద్దతును అందిస్తుంది. ఈ తరగతి యొక్క ఒక వస్తువు మూల భాష నుండి లక్ష్య భాషకు అనువాదాల సమితిని కలిగి ఉంటుంది. QTranslator అనువాద ఫైల్‌లో అనువాదాలను చూసే విధులను అందిస్తుంది. Qt Linguist ఉపయోగించి అనువాద ఫైళ్లు సృష్టించబడతాయి.</translation>
    </message>
</context>
</TS>
