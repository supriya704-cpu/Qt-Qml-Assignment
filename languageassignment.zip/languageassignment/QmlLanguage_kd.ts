<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="kn_IN">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="59"/>
        <location filename="main.qml" line="60"/>
        <source>Hello World</source>
        <translation>ಹಲೋ ವರ್ಲ್ಡ್</translation>
    </message>
    <message>
        <location filename="main.qml" line="61"/>
        <source>The QTranslator class provides internationalizationsupport for text output.An object of this class contains a set of translations from a source language to a target language. QTranslator provides functions to look up translations in a translation file. Translation files are created using Qt Linguist.</source>
        <translation>QTranslator ವರ್ಗವು ಪಠ್ಯ output ಟ್‌ಪುಟ್‌ಗಾಗಿ ಅಂತರರಾಷ್ಟ್ರೀಯ ಬೆಂಬಲವನ್ನು ಒದಗಿಸುತ್ತದೆ. ಈ ವರ್ಗದ ಒಂದು ವಸ್ತುವು ಮೂಲ ಭಾಷೆಯಿಂದ ಉದ್ದೇಶಿತ ಭಾಷೆಗೆ ಅನುವಾದಗಳ ಗುಂಪನ್ನು ಒಳಗೊಂಡಿದೆ. ಅನುವಾದ ಕಡತದಲ್ಲಿ ಅನುವಾದಗಳನ್ನು ಹುಡುಕಲು QTranslator ಕಾರ್ಯಗಳನ್ನು ಒದಗಿಸುತ್ತದೆ. ಅನುವಾದ ಫೈಲ್‌ಗಳನ್ನು ಕ್ಯೂಟಿ ಭಾಷಾಶಾಸ್ತ್ರಜ್ಞ ಬಳಸಿ ರಚಿಸಲಾಗಿದೆ.</translation>
    </message>
</context>
</TS>
