#include "dialog.h"
#include "ui_dialog.h"
#include "mythread.h"

Dialog::Dialog(QWidget *parent):
     QMainWindow(parent),
     ui(new Ui::Dialog)
{
    ui->setupUi(this);
                               //stop and fromstop
    mThread = new mythread(this,false,false);
    //connect(sender, SIGNAL,receiver,SLOT);
            connect(mThread, SIGNAL(valueChanged(int)),this, SLOT(onValueChanged(int)));

}


Dialog::~Dialog()
{
    delete ui;
}


//Counter displaying using label
void Dialog::onValueChanged(int count)
{
    ui->label->setText(QString::number(count));//displaying the counter
}



//pushButton 1 to start the counter
//clicking on start stop is false
//clicking on start it starts from the counter it stopped
void Dialog::on_pushButton_clicked()
{
 mThread->Stop=false;
// ui->label->setText("Start");
 mThread->fromstop=true;
 mThread->start();
 ui->label_2->setText("Counter is Started");
 //mThread->fromstop=true;

}



//pushButton 2 to stop the counter
void Dialog::on_pushButton_2_clicked()
{
ui->label->setText("Stop");
mThread->Stop=true;
//mThread->fromstop=false;
ui->label_2->setText("Stopped the Counter");

}



//pushbutton 3 to reset the counter to 0
void Dialog::on_pushButton_3_clicked()
{
    ui->label->setText("Reset");
    mThread->Stop= false;
    mThread->fromstop=false;
    ui->label_2->setText("Counter is Reset");//displaying in label
    mThread->start();



}

