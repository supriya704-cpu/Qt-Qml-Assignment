#include "mythread.h"
#include<QDebug>
#include<QMutex>
                                  //stop    tostart from where it is stopped
mythread::mythread(QObject *parent, bool b, bool a):
    QThread(parent), Stop(b), fromstop(a)
{

}


void mythread::run()
{
/*checking the condition if its fromstop is set true
    then it assigns the value to i */

    if(this->fromstop){
       // i=value;
   //assign
     i=value;
    }
    //or it assigns the i value to 0
        else {
           i=0;

}
//
    for(;i<=100;i++)
    {

        //one thread can access at a time
        QMutex mutex;
        mutex.lock(); //locking
        if(this->Stop)//if stopped

            //value=i;
        {
            value=i; // storing the counter value
        mutex.unlock(); //unlocking
        break;

        }
        mutex.unlock();
        emit valueChanged(i);// emit the signal on valuechanged
        this->msleep(300);
    }

}


