#ifndef MYTHREAD_H
#define MYTHREAD_H

#include<QObject>
#include<QThread>

class mythread:public QThread
{
    Q_OBJECT
public:
   explicit mythread(QObject *parent = 0, bool b = false, bool a = false);

    void run();// mythread.cpp

    bool Stop;
    bool fromstop;
int value,i;    //storing and iteration
signals:

    void valueChanged(int);
public slots:

};

#endif // MYTHREAD_H
